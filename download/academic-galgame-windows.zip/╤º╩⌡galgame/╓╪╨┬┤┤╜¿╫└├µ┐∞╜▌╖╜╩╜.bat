@echo off
chcp 936 >nul
cd /d "%~dp0"
echo.
"ѧ��galgame.exe" --shortcut
echo.
pause